<html>
<head>
	<title>Nuevo Contacto</title>
</head>
<body>
	<p>Nuevo Contacto desde la web</p>
	<hr>
	<u> 
		<li>
			<strong>Email:</strong>
			{{ $data['email'] }}
		</li>
		
	</u>
	<hr>
</body>
</html>