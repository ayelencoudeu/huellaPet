<html>
<head>
	<title>Nuevo Contacto</title>
</head>
<body>
	<p>Nuevo Contacto desde la web</p>
	<hr>
	<u> 

		<li>
			<strong>Nombre:</strong>
			<?php echo e($data['nombre']); ?>

		</li>
		<br/>
		<li>
			<strong>Email:</strong>
			<?php echo e($data['email']); ?>

		</li>
		<br/>
		<li>
			<strong>Mensaje:</strong>
			<?php echo e($data['mensaje']); ?>

		</li>
	</u>
	<hr>
</body>
</html>