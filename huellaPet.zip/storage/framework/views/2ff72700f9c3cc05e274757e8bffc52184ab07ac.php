             
<?php $__env->startSection('home'); ?>
            
    <div class="productos" id="productos">
        <h1>Listado de Categorías</h1>
            <hr>
        <div class="todoslosproductos">
            <a href="<?php echo e(url('/admin/categories/create')); ?>" class="btn btn-primary">Nueva Categoría</a>
            <table class="table tabla-categorias">
                <tbody>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Opciones</th>
                    </tr>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td class="text-center"><?php echo e($datoCategoria->id); ?></td>
                        <td><?php echo e($datoCategoria->name); ?></td>
                        <td><?php echo e($datoCategoria->description); ?></td>
                        <td class="td-actions text-right">
                            <form method="post" action="<?php echo e(url('/admin/categories/'.$datoCategoria->id )); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                
                                <a href="" type="button" rel="tooltip" title="ver Categoría">
                                    <i class="fa fa-user"></i>
                                </a>
                                <a href="<?php echo e(url('/admin/categories/'.$datoCategoria->id.'/edit')); ?>" type="button" rel="tooltip" title="editar Categoría" >
                                    <i class="fa fa-edit"></i>
                                </a>
                            </form>
                        </td>
                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div>           
                <?php echo e($categories->links()); ?>    
            </div>                     
        </div>
    </div>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>