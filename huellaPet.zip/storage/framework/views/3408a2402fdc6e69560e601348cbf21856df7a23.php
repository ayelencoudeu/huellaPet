 
<?php $__env->startSection('contacto'); ?>


	<div class="consultanos" id="contacto">
	   <h3>DEJANOS TU CONSULTA</h3>
	   <hr>
	   <form class="contact_form" action="<?php echo e(url('/contacto')); ?>" method="post" name="contact_form">
	   	 <?php echo e(csrf_field()); ?>

	      <ul>
	         <li>
	            <input id="nombre" type="text" name="nombre" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('nombre')); ?>" required placeholder="*Nombre" />
	            <?php if($errors->has('nombre')): ?>
	            <span class="invalid-feedback">
	              <strong><?php echo e($errors->first('nombre')); ?></strong>
	            </span>
	            <?php endif; ?>  
			</li>
	        <li>
	            <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="*Email" />
		        <?php if($errors->has('email')): ?>
		        <span class="invalid-feedback">
		            <strong><?php echo e($errors->first('email')); ?></strong>
		        </span>
            	<?php endif; ?>
			</li>
	        <li>
	        <textarea type="textarea" id="mensaje" class="form-control<?php echo e($errors->has('long_description') ? ' is-invalid' : ''); ?>" rows="5" name="mensaje" required placeholder="*tu mensaje" /><?php echo e(old('mensaje')); ?></textarea>
            <?php if($errors->has('mensaje')): ?>
            <span class="invalid-feedback">
                <strong><?php echo e($errors->first('mensaje')); ?></strong>
            </span>
            <?php endif; ?>    
			</li>
	        <li>
	        	<input type="submit" name="enviarcons" value="<?php echo e(__('enviar')); ?>" placeholder="ENVIAR" >
            	
	        </li>
	      </ul>
	   </form>
	</div>

	<div class="newsleterr">
		<h3>Sumate a nuestro newsletter</h3>
		<hr>
		<form class="contact_form" action="<?php echo e(url('/contacto/news')); ?>" method="post" name="contact_form">
		<?php echo e(csrf_field()); ?>

	 		<ul>
				<li>
					<input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="*Email" />
			        <?php if($errors->has('email')): ?>
			        <span class="invalid-feedback">
			            <strong><?php echo e($errors->first('email')); ?></strong>
			        </span>
	            	<?php endif; ?>
				</li>
				<li>
					<input type="submit" name="enviarnews" value="<?php echo e(__('enviar')); ?>" placeholder="ENVIAR">
				</li>
			</ul>
		</div>	
		</form>

	</div>
	<div class="ubicanos">
		<h3>ACERCATE A NUESTRO LOCAL</h3>
		<hr>
		<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13136.066850016401!2d-58.3815704!3d-34.6037389!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x11bead4e234e558b!2sObelisco!5e0!3m2!1ses!2sar!4v1521055859994" width="100%" height="280px" frameborder="0" style="border: 4px solid #F2CD13" allowfullscreen></iframe>
	</div>



    
    
  <?php $__env->stopSection(); ?>



    


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>