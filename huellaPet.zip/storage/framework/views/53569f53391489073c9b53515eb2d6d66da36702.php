<?php $__env->startSection('show'); ?>

    
    <?php if(session('agregoExito')): ?> 
        <div><?php echo e(session('agregoExito')); ?></div>
    <?php endif; ?>
   
   <div class="tiendaheader">
        <input type="checkbox" id="check">
        <label for="check" class="icon-menu"><h1>Categorias</h1></label>
      
  </div>
        <nav class="menu">
           <ul>
           <?php $__currentLoopData = $mostrar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoBase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
          <li>
            <a class="btn-comprar" href="<?php echo e(url('/categories/'.$datoBase->id)); ?>"><?php echo e($datoBase->name); ?></a>
          </li>
           </ul>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </nav>
<div class="article">
   <h2>Todas las ofertas en Huella PET<h2>
  <p>Tenemos de todo para tu mascota</p>
</div>
<div class="productos" >
        <div class="todoslosproductos">
            <?php $__currentLoopData = $dato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoBase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <article class="product">
                    <img src=" <?php echo e($datoBase->feature_image_url); ?>" alt="comida para perro">
                    <h2><a href="<?php echo e(url('/products/'.$datoBase->id)); ?>"><?php echo e($datoBase->name); ?></a></h2>
                    <p><?php echo e($datoBase->description); ?></p>
                    <div class="btn-comprar">
                        <a href="<?php echo e(url('/products/'.$datoBase->id)); ?>">Comprar</a>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       
</div>
<br>
<br>   
<br>
   
</div>
  <div>
      <?php echo e($dato->links()); ?>

  </div>
  <hr>  
<div>
    <?php echo $__env->make('prefinal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>