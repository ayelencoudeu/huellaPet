<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">

   <head>
      <meta charset="utf-8">
      <meta lang="es">
      <meta name="author" content="DH, Coudeu, Baier, Gaab, Ojeda">
      <meta name="description" content="Huella Pet es tu Pet Shop amigo y lo mejor es que Online, no tenes que salir de tu casa, comprá lo que necesitas cuando queres.">
      <meta name="keywords" content="Huella Pet, pet shop, online, mascota, alimentos, perro">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Huella Pet</title>
       

      

      <!-- CSS del proyecto -->
      <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/huellacss.css')); ?>">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
   </head>
<!-- Encabezado -->
   <body>
      <div class="container">
         <div class="datosarribacontacto">
            <div class="dtc">
               <img src="<?php echo e(asset('images/iconoemail.png')); ?>" alt="email">
               <p>ventas@huellapet.com</p>
            </div>
            <div class="dtc">
               <img src="<?php echo e(asset('images/iconowatsap.png')); ?>" alt="telefono">
               <p>(011)1548352738</p>
            </div>
        </div>
        <div class="encabezado" id="alturaencabezado">
            <?php if(auth()->guard()->guest()): ?> 
               <div class='cont-reg-carr'>
                  <nav class='nav-reg'>
                     <ul>
                        <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('Ingresa')); ?></a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('Registrate')); ?></a></li>
                     </ul>
                  </nav>
                  <div class='carrito'>
                     <img src="<?php echo e(asset('images/carrito.png')); ?>" alt='carrito'><p>Carrito</p>
                  </div>
               </div>
            <?php else: ?>
            <div class="menuUsuario">  
               <div class="dropdown Imagen" >
                  <img src="<?php echo e(asset('images/usuario/'.Auth::user()->imagen)); ?>" width="50" height="50" style="border-radius: 50px; border: 2px solid white;">
               </div>   
                
               <div class="dropdown">
                  <button class="dropbtn"><?php echo e(Auth::user()->nombre); ?></button>
                     <div class="dropdown-content">
                        <a href="<?php echo e(route('modificarDatos', ['id' => Auth::user()->id])); ?>">Editar Datos</a>

                           <?php if(auth()->user()->admin): ?>
                        <a href="<?php echo e(url('/admin/products')); ?>">Editar Productos</a>
                        <a href="<?php echo e(url('/admin/categories')); ?>">Editar Categorias</a>
                           <?php endif; ?>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><?php echo e(__('Salir')); ?></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                           <?php echo csrf_field(); ?>
                        </form>
                     </div>
               </div>
               <div class="dropdown">
                  <button class="dropbtn">Mi Carrito</button>
                     <div class="dropdown-content">
                        <a href="<?php echo e(url('/usuarioCompra')); ?>">Mi Compra</a>
                        <a href="">Lista</a>
                     </div> 
               </div>
            </div>
            <?php endif; ?>

            <div class="logo">
               <img src="<?php echo e(asset('images/logo.png')); ?>">
            </div>
            <nav class="navegadorprincipal">
               <ul>
                  <li><a href="<?php echo e(url('/home')); ?>"><?php echo e(__('Inicio')); ?></a></li>
                  <li><a href="<?php echo e(url('/nosotros')); ?>">Nosotros</a></li>
                  <li><a href="<?php echo e(url('/categories')); ?>">Tienda</a></li>
                  <li><a href="<?php echo e(url('/faqs')); ?>">Preguntas</a></li>
                  <li><a href="<?php echo e(url('/contacto')); ?>">Contacto</a></li>
               </ul>
            </nav>
            <nav class="navegadorprincipalmobile">
               <div class="dropdown">
                  <button class="dropbtn" onclick="desplegar(this)">
                     <img src="<?php echo e(asset('images/logoMenu.png')); ?>">
                  </button>
                  <div class="dropdown-content">
                     <a href="<?php echo e(url('/home')); ?>"><?php echo e(__('Inicio')); ?></a>
                     <a href="<?php echo e(url('/nosotros')); ?>">Nosotros</a>
                     <a href="<?php echo e(url('/categories/')); ?>">Tienda</a>
                     <a href="<?php echo e(url('/faqs')); ?>">Preguntas</a>
                     <a href="<?php echo e(url('/contacto')); ?>">Contacto</a>
                  </div>
               </div>
            </nav>
         </div>  
      </div>
      <div>
         <?php echo $__env->yieldContent('registro'); ?>    
      </div>
      <div>
         <?php echo $__env->yieldContent('modificar'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('login'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('home'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('show'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('usuarioCompra'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('nosotros'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('faqs'); ?>
      </div>
      <div>
         <?php echo $__env->yieldContent('contacto'); ?>
      </div>
    
      <div class="seguinos">
         <p class="legales2">Copy right Lorem ipsum dolor sit amet.</p>
      </div>
</body>

   <script type="text/javascript">
   function desplegar(alturaencabezado){
      var obj = document.getElementById('alturaencabezado'); 
      
      obj.style.height = "380px";
   }
   
   function contraer(alturaencabezado){
      var obj = document.getElementById('alturaencabezado'); 
      
      obj.style.height = "400px";
   }

    </script>
</html>