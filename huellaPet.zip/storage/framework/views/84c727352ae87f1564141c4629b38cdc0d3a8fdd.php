<?php $__env->startSection('show'); ?>
<div class="productos" >
    
    <?php if(session('agregoExito')): ?> 
        <div><?php echo e(session('agregoExito')); ?></div>
    <?php endif; ?>
   <div>
         <h1>Categoria: <?php echo e($category->name); ?></h1>
    </div>
    <div>
        <h2><?php echo e($category->description); ?></h2>
    </div>
    <hr>
        <div class="todoslosproductos">
           <?php $__currentLoopData = $dato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoBase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <article class="product">
                <img src=" <?php echo e($datoBase->feature_image_url); ?>" alt="comida para perro">
                <h2>
                    <a href="<?php echo e(url('/products/'.$datoBase->id)); ?>"><?php echo e($datoBase->name); ?></a>  
                </h2>
                <p><?php echo e($datoBase->description); ?></p>
                <div class="btn-comprar">
                    <a href="<?php echo e(url('/products/'.$datoBase->id)); ?>">Comprar</a>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
    <div>
        <?php echo e($dato->links()); ?>

    </div>
</div>

<div>
    <?php echo $__env->make('prefinal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>