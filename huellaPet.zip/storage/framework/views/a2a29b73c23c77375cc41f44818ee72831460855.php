<?php $__env->startSection('registro'); ?>
<!-- Formulario html -->

    <div class="newsleterr" onclick="contraer(this)">
      <h3><strong>CREAR CUENTA</strong></h3>

      <form class="contact_form" method="POST" enctype="multipart/form-data" action="">
         <?php echo e(csrf_field()); ?>

      <ul>
        <li>
           <input id="nombre" type="text" name="nombre" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" value="<?php echo e(old('nombre')); ?>" required autofocus placeholder="*Nombre" />
            <?php if($errors->has('nombre')): ?>
            <span class="invalid-feedback">
              <strong><?php echo e($errors->first('nombre')); ?></strong>
            </span>
            <?php endif; ?>      
        </li>
        <li>
          <input id="apellido" type="text" class="form-control<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" name="apellido" value="<?php echo e(old('apellido')); ?>" required autofocus placeholder="*Apellido"/>
          <?php if($errors->has('apellido')): ?>
          <span class="invalid-feedback">
            <strong><?php echo e($errors->first('apellido')); ?></strong>
          </span>
          <?php endif; ?>
        </li>
        <li>
          <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="*Email" />
            <?php if($errors->has('email')): ?>
            <span class="invalid-feedback">
                <strong><?php echo e($errors->first('email')); ?></strong>
            </span>
            <?php endif; ?>
        </li>
        <li>
          <select name="nacionalidad" placeholder="Nacionalidad" id="nacionalidad" class="form-control<?php echo e($errors->has('nacionalidad') ? ' is-invalid' : ''); ?>" required />
            <option value=1>Argentina</option>
            <option value=2>Uruguay</option>
            <option value=3>Brasil</option>
            <option value=4>Otro..</option>
          </select>
          <?php if($errors->has('nacionalidad')): ?>
            <span class="invalid-feedback">
                <strong><?php echo e($errors->first('nacionalidad')); ?></strong>
            </span>
          <?php endif; ?>
        </li>
        <li>
            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="*Clave" >
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
        <li>
            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required placeholder="*Confirmar Clave">
        </li>
        <li>
           
           <input id="imagen" type="file" name="imagen" class="form-control<?php echo e($errors->has('imagen') ? ' is-invalid' : ''); ?>" required />
           <?php if($errors->has('imagen')): ?>
            <span class="invalid-feedback">
                <strong><?php echo e($errors->first('imagen')); ?></strong>
            </span>
            <?php endif; ?>
        </li>
        <li>
            <input type="submit" name="registro" value="<?php echo e(__('Registro')); ?>"  class="boton"><br>
      </li>
      </ul>
      </form>
      <p class="legales">Al registrarme, declaro que soy mayor de edad y acepto los Términos y condiciones y las Políticas de Huella Pet.</p>
    </div>
<?php $__env->stopSection(); ?>
<script src="<?php echo e(asset('js/formulario.js')); ?>" type="text/javascript"></script>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>