<html>
<head>
	<title>Nuevo Pedido</title>
</head>
<body>
	<p>Se a realizado un nuevo pedido</p>
	<p>Estos son los datos del cliente que realizo el pedido</p>
	<u> 
		<li>
			<strong>Nombre:</strong>
			<?php echo e($user->nombre); ?>

		</li>
		<br/>
		<li>
			<strong>Email:</strong>
			<?php echo e($user->email); ?>

		</li>
		<br/>
		<li>
			<strong>Fecha de Pedido:</strong>
			<?php echo e($cart->order_date); ?>

		</li>
	</u>
	<hr>
	<p>Detalles del Pedido:</p>
	<ul>
		<?php $__currentLoopData = $cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<li> <?php echo e($detalle->product->name); ?> x <?php echo e($detalle->quantity); ?> ($ <?php echo e($detalle->quantity * $detalle->product->price); ?>)</li>
		<hr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>

	<p><strong>Importe a pagar:_$</strong><?php echo e($cart->total); ?></p>
	
	
</body>
</html>