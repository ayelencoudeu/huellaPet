<?php $__env->startSection('show'); ?>
    <div class="productos">
        <h3>Producto Seleccionado</h3>
        <hr>
        <div class="productoSeleccionado">
            <img src="<?php echo e($product->feature_image_url); ?>" alt="imagenProducto" class="imagenProducto">
                <?php if(session('agregoExito')): ?> 
            <div><?php echo e(session('agregoExito')); ?></div>
                <?php endif; ?>
            
            <div class="productosItems">
                <?php $__currentLoopData = $imageMostrar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $muestra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img src="<?php echo e($muestra->url); ?>" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="productosDetalle">
                <h2><?php echo e($product->name); ?></h2>
                <h4><?php echo e($product->category->name); ?></h4>
                <h5>$<?php echo e($product->price); ?></h5>
            </div>

            <div class="productosDescripcion">
                <p><?php echo e($product->long_description); ?></p>
            </div>

                <div>
                    <form method="post" action="<?php echo e(url('/cart')); ?>" class="formProductos">
                        <?php echo e(csrf_field()); ?>

                        <div>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <h4>Ingrese la cantidad deseada:</h4>
                        </div>
                        <div>
                            <input type="number" value="1" name="quantity" style="background-color: lightyellow;">
                        </div>
                            <button type="submit" class="addProducto">Comprar</button>
                    </form>
                </div>
        </div>    
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>