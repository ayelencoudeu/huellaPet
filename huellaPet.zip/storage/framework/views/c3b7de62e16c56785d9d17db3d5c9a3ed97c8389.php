<?php $__env->startSection('modificar'); ?>
<!-- Formulario html -->
    <div class="newsleterr" onclick="contraer(this)">
      <h3><strong>MODIFICAR DATOS</strong></h3>

      <form class="contact_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/modificarDatos/'.Auth::user()->id.'/edit')); ?>">
         <?php echo e(csrf_field()); ?>

      <ul>
        <li>

          <input id="nombre" type="text" name="nombre" class="form-control<?php echo e($errors->has('nombre') ? ' is-invalid' : ''); ?>" name="nombre" value="<?php echo e(Auth::user()->nombre); ?>" autofocus placeholder="<?php echo e(Auth::user()->nombre); ?>" />
            <?php if($errors->has('nombre')): ?>
            <span class="invalid-feedback">
              <strong><?php echo e($errors->first('nombre')); ?></strong>
            </span>
            <?php endif; ?>      
        </li>
        <li>
         <input id="apellido" type="text" class="form-control<?php echo e($errors->has('apellido') ? ' is-invalid' : ''); ?>" name="apellido" value="<?php echo e(Auth::user()->apellido); ?>" autofocus placeholder="<?php echo e(Auth::user()->apellido); ?>"/>
          <?php if($errors->has('apellido')): ?>
          <span class="invalid-feedback">
            <strong><?php echo e($errors->first('apellido')); ?></strong>
          </span>
          <?php endif; ?>
        </li>
        <li>
          <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" placeholder="*Clave" >
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>

        <li>
          
        <li>
          <input type="file" name="imagen" placeholder="Subi tu foto" />

        </li>
        <li>
          <input type="submit" name="registro" value="Guardar" >
        </li>
      </ul>
      </form>
      <p class="legales">Al registrarme, declaro que soy mayor de edad y acepto los Términos y condiciones y las Políticas de Huella Pet.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>