 
<?php $__env->startSection('usuarioCompra'); ?>
<div class="productos" id="productos">
    <h1>Mi Compra</h1>

            <?php if(session('notification')): ?> 
                <div><?php echo e(session('notification')); ?></div>
            <?php endif; ?>
            
            <?php if(session('cartStatus')): ?> 
                <div><?php echo e(session('cartStatus')); ?></div>
            <?php endif; ?>
            <p>El carrito de presenta: <?php echo e(auth()->user()->cart->details->count()); ?> producto/s</p>
            <table class="table tabla-categorias">
                    <tr>
                        <th>Producto</th>
                        <th>Nombre</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                        <th>SubTotal</th>
                        <th>Opciones</th>
                    </tr>
                    <tbody>
                        <hr>
                        <?php $__currentLoopData = auth()->user()->cart->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                            <td>
                                <img src="<?php echo e($detail->product->feature_image_url); ?>" height="50px" style="border-radius: 50px;">
                            </td>
                            <td>
                                <a href="<?php echo e(url('/products/'.$detail->product->id)); ?>" target="_blank"><?php echo e($detail->product->name); ?></a>
                            </td>
                            <td>$ <?php echo e($detail->product->price); ?>.-</td>
                            <td><?php echo e($detail->quantity); ?> unidad/es</td>
                            <td>$ <?php echo e($detail->quantity * $detail->product->price); ?>.-</td>
                            <td>
                                <form method="post" action="<?php echo e(url('/cart')); ?>">
                                    <?php echo e(csrf_field()); ?>

                                    <?php echo e(method_field('DELETE')); ?>

                                    <input type="hidden" name="cart_detail_id" value="<?php echo e($detail->id); ?>">
                                    <button type="submit" rel="tooltip" title="eliminar Producto" >
                                        <i class="fa fa-times"> Eliminar</i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
            </table>
            <p class="p-carrito"><strong>Importe a Pagar:</strong> <?php echo e(auth()->user()->cart->total); ?></p> 
            <div class="importe-carrito">
            
                <form method="post" action="<?php echo e(url ('/order')); ?>" >
                    <?php echo e(csrf_field()); ?>


                    <input type="submit" rel="tooltip" name="PagarEfectivo" value="Pagar en Efectivo">
                    <input type="button" rel="tooltip" name="PagoTarjeta" value="Pagar con Tarjeta" onclick="window.location = 'https://www.mercadopago.com.ar'" target="_new">
               </form>

            </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>