<?php $__env->startSection('login'); ?>
<div class="login-user">
    <h3><strong>¡Hola Bienvenido!</strong></h3>
    <form method="POST" action="<?php echo e(route('login')); ?>" class="contact_form">
      <?php echo e(csrf_field()); ?>

        <ul>
            <li>
              <input id="email" type="text" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required placeholder="*Email" />
                <?php if($errors->has('email')): ?>
                <span class="invalid-feedback">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                <?php endif; ?>
            </li>
            <li>
                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="*Clave" >
                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?> 
            </li>
            <li>
                <label>Recordarme</label>
                <input type="checkbox" name="remember" value="ok">
            </li>
            <li>
                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>"><?php echo e(__('¿Olvidaste tu contraseña?')); ?></a>
            </li>
        </ul>
        <input type="submit" name="login" value="login" class="boton"><br>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>