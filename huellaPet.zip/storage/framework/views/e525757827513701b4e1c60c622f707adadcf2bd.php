<?php $__env->startSection('registro'); ?>
<!-- Formulario html -->
   <div class="editCategory">
      <h3><strong>Registrar Nueva Categoría</strong></h3>  
         <?php if($errors->any()): ?>
      <div>
         <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li>
                 <?php echo e($error); ?>

               </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
      </div>
         <?php endif; ?>

      <form class="contact_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/admin/categories')); ?>">
         <?php echo e(csrf_field()); ?>

         <ul>
            <li>
               <input id="name" type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('name')); ?>" required autofocus placeholder="*Nombre de la categoría" />
               <?php if($errors->has('name')): ?>
               <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('name')); ?></strong>
               </span>
               <?php endif; ?>      
            </li>
            <li>
               <textarea id="description" class="form-control<?php echo e($errors->has('long_description') ? ' is-invalid' : ''); ?> category-description" rows="5" name="description" required placeholder="*Descripción de la categoría" /><?php echo e(old('description')); ?></textarea>
               <?php if($errors->has('description')): ?>
               <span class="invalid-feedback">
                   <strong><?php echo e($errors->first('description')); ?></strong>
               </span>
               <?php endif; ?>
            </li>
            <li>
               <input type="submit" name="registro" value="<?php echo e(__('Crear')); ?>" >
            </li>
            <span><a href="<?php echo e(url('/admin/categories/')); ?>" >Cancelar</a></span>
         </ul>
      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>