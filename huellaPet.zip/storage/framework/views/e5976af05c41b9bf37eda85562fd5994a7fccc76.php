<?php $__env->startSection('registro'); ?>

<!-- Formulario html -->
   <div class="editCategory">
      <h3><strong>Editar Producto</strong></h3>
         <?php if($errors->any()): ?>
      <div>
         <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
              <?php echo e($error); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
      </div>
         <?php endif; ?>
      <form class="contact_form" method="POST" enctype="multipart/form-data" action="<?php echo e(url('/admin/products/'.$product->id.'/edit')); ?>">
         <?php echo e(csrf_field()); ?>

         <ul>
            <li>
               <select name="category_id"> 
                  <option value="0">General</option>
                     <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datoCategoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($datoCategoria->id); ?>" <?php if( $datoCategoria->id == old('category_id',$product->category_id)): ?> selected <?php endif; ?> ><?php echo e($datoCategoria->name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>    
            </li>

            <li>
               <input id="name" type="text" name="name" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" value="<?php echo e(old('name', $product->name)); ?>" required autofocus/>
               <?php if($errors->has('name')): ?>
               <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('name')); ?></strong>
               </span>
               <?php endif; ?>      
            </li>
            <li>
               <input id="description" type="text" class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>" name="description" value="<?php echo e(old('description', $product->description)); ?>" required autofocus/>
               <?php if($errors->has('description')): ?>
               <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('description')); ?></strong>
               </span>
               <?php endif; ?>
            </li>
            <li>
               <textarea id="long_description" class="form-control<?php echo e($errors->has('long_description') ? ' is-invalid' : ''); ?> category-description" name="long_description" rows="5" required /><?php echo e(old('description',$product->description)); ?></textarea>
               <?php if($errors->has('long_description')): ?>
               <span class="invalid-feedback">
                  <strong><?php echo e($errors->first('long_description')); ?></strong>
               </span>
               <?php endif; ?>
            </li>
            
            <li>
               <input type="number" id="price" class="form-control<?php echo e($errors->has('price') ? ' is-invalid' : ''); ?>" name="price" required value="<?php echo e(old('description', $product->price)); ?>" step="0.01">
               <?php if($errors->has('price')): ?>
                   <span class="invalid-feedback">
                       <strong><?php echo e($errors->first('price')); ?></strong>
                   </span>
               <?php endif; ?>
            </li>
            <li>
               <small>Edita las imagenes desde el editor de imagenes</small>
            </li>
            
               <input type="submit" name="registro" value="<?php echo e(__('Crear')); ?>" >
               <span><a href="<?php echo e(url('/admin/products/')); ?>" >Cancelar</a></span>
         </ul>
      </form>
   </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>