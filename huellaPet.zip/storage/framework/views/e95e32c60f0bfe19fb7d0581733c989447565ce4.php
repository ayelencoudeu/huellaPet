             
<?php $__env->startSection('home'); ?>
            

 <div class="productos" id="productos">
             <h1>Imagenes de Productos "<?php echo e($product->name); ?>" </h1>
             <hr>
             <div class="todoslosproductos">
        

        <form method="post" action="" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <input type="file" name="photo" requerido>
            <button type="submit" >Subir Nueva Imagen</button>
        </form>
        
        <a href="<?php echo e(url('/admin/products')); ?>" class="btn btn-primary">Volver</a>

        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div>
            <div>
                <img src="<?php echo e($image->url); ?>" width="300">
                <form method="post" action="">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>


                    <input type="hidden" name="image_id" value="<?php echo e($image->id); ?>">
                <button type="submit">Eliminar Imagen</button>
               <?php if($image->feature): ?>
               <button tupe="button">
                    <i class="material-icons">favorita</i>
                </button>
               <?php else: ?>
                 <a href="<?php echo e(url('/admin/products/'.$product->id.'/images/select/'.$image->id)); ?>">
                    <i class="material-icons">favorita</i>
                </a>
               <?php endif; ?>
                </form>
                

            </div>
        </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
                               
    </div>
</div>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>